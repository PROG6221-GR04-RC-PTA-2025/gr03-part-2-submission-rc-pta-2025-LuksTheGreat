﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE_part2_ST10449800
{
    class Program
    {
        // List of phishing tips
        static List<string> phishingTips = new List<string>();

        // Memory to recall user information
        static Dictionary<string, string> memory = new Dictionary<string, string>();

        // Keyword-based responses
        static Dictionary<string, List<string>> keywordResponses = new Dictionary<string, List<string>>();

        // To track the current topic
        static string currentTopic = "";

        static void Main(string[] args)
        {
            InitializeResponses();

            Console.OutputEncoding = Encoding.UTF8;

            // Display ASCII Art of Cyberbot
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
  _________________________________________
 /                                         \
|   _________________________________       |
|  |                                 |      |
|  |           C Y B E R B O T       |      |
|  |_________________________________|      |
|                                           |
 \_________________________________________/
        \___________________________/
         ||                       ||
         ||                       ||
         ||_______________________||
         |_________________________|
");
            Console.ResetColor();

            Console.WriteLine("🛡️  Welcome to the Cybersecurity Chatbot!");
            Console.WriteLine("=======================================\n");

            Console.Write("Before we begin, what's your name? ");
            var name = Console.ReadLine();
            memory["name"] = name;

            Console.WriteLine($"\nHi {name}, I'm here to help you stay safe online.");

            while (true)
            {
                Console.Write("\nYou: ");
                var input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Chatbot: I didn't catch that. Can you say it again?");
                    continue;
                }

                input = input.ToLower();

                // Exit condition
                if (input == "exit" || input == "bye")
                {
                    Console.WriteLine($"Chatbot: Stay safe, {name}! Goodbye.");
                    break;
                }

                // Sentiment detection
                if (CheckSentiment(input)) continue;

                // Keyword recognition
                if (CheckKeywords(input)) continue;

                // Conversation flow (follow-up)
                if (input.Contains("more") && currentTopic == "phishing")
                {
                    Console.WriteLine("Chatbot: Here's another phishing tip:");
                    Console.WriteLine("Chatbot: " + GetRandomPhishingTip());
                    continue;
                }

                // Unrecognized input fallback
                Console.WriteLine("Chatbot: I'm not sure I understand. Could you try asking in a different way?");
            }
        }

        // Initialize keyword responses and phishing tips
        static void InitializeResponses()
        {
            keywordResponses["password"] = new List<string>
            {
                "Use strong, unique passwords for every account.",
                "Avoid using personal info like birthdays in your passwords.",
                "Consider using a password manager to store secure passwords."
            };

            keywordResponses["scam"] = new List<string>
            {
                "Be cautious of messages asking for personal info.",
                "Scammers often pretend to be from trusted sources.",
                "Never send money or personal info to unknown contacts."
            };

            keywordResponses["privacy"] = new List<string>
            {
                "Regularly review your privacy settings on social media.",
                "Avoid sharing sensitive data with untrusted websites.",
                "Use private browsing or a VPN to protect your activity."
            };

            phishingTips.AddRange(new[]
            {
                "Be cautious of emails with urgent language or threats.",
                "Check sender email addresses carefully for subtle typos.",
                "Avoid clicking links in suspicious messages.",
                "Hover over links to preview URLs before clicking.",
                "Don't download unexpected attachments from emails."
            });
        }

        // Check for cybersecurity-related keywords
        static bool CheckKeywords(string input)
        {
            foreach (var keyword in keywordResponses.Keys)
            {
                if (input.Contains(keyword))
                {
                    currentTopic = keyword;

                    // Store user's interest for memory recall
                    if (!memory.ContainsKey("interest"))
                        memory["interest"] = keyword;

                    var responses = keywordResponses[keyword];
                    var randomResponse = responses[new Random().Next(responses.Count)];
                    Console.WriteLine("Chatbot: " + randomResponse);
                    return true;
                }
            }

            if (input.Contains("phishing"))
            {
                currentTopic = "phishing";
                Console.WriteLine("Chatbot: " + GetRandomPhishingTip());
                return true;
            }

            return false;
        }

        // Check sentiment and respond with empathy
        static bool CheckSentiment(string input)
        {
            if (input.Contains("worried"))
            {
                Console.WriteLine("Chatbot: It's completely okay to feel worried. You're not alone—we'll walk through this together.");
                return true;
            }
            if (input.Contains("frustrated"))
            {
                Console.WriteLine("Chatbot: I get that this can be frustrating. Cybersecurity can be tricky, but you're doing great.");
                return true;
            }
            if (input.Contains("curious"))
            {
                Console.WriteLine("Chatbot: Curiosity is great! Let’s explore more about online safety.");
                return true;
            }
            return false;
        }

        // Return a random phishing tip
        static string GetRandomPhishingTip()
        {
            var rand = new Random();
            return phishingTips[rand.Next(phishingTips.Count)];
        }
    }
}
